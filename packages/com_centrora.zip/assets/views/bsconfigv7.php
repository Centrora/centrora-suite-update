<?php
/**
 * Created by PhpStorm.
 * User: suraj
 * Date: 3/06/2016
 * Time: 3:18 PM
 */
if (!defined('OSE_FRAMEWORK') && !defined('OSEFWDIR') && !defined('_JEXEC'))
{
 die('Direct Access Not Allowed');
}
oseFirewall::checkDBReady ();
$this->model->getNounce();
$status = oseFirewall::checkSubscriptionStatus(false);
//$seoConfArray = array();
$seoConfArray = $this->model->getSeoConfiguration();
$status = oseFirewall::checkSubscriptionStatus(false);
//$status = false;
?>
<div id="oseappcontainer">
 <div class="container wrapbody">
  <?php
  $this->model->showLogo ();
  //$this->model->showHeader ();
  ?>
     <div class="row">
         <div class="col-md-12">
             <div class="panel panel-primary plain ">
                 <!-- Start .panel -->

                 <div class="panel-body wrap-container">
                     <div class="row row-set">
                         <div class="col-sm-3 p-l-r-0">
                             <div id="c-tag">
                                 <div class="col-sm-12" style="padding-left: 0px;">
                                <span class="tag-title">Firewall Configuration<span>
                                 </div>
                                 <p class="tag-content">To increase your Website's security level by enabling firewall settings and file upload validations.</p>
                             </div>
                         </div>
                         <div class="col-sm-9">
                         <div class="col-sm-3">
                             <div class="vs-line-1">
                                 <div id="fw-overview" class="vs-line-1-title fw-hover"> <i class="fa fa-fire"></i></div>
                                 <div class="vs-line-1-number">
                                     Firewall Overview
                                 </div>
                             </div>
                         </div>
                             <div class="col-sm-3">
                                 <div class="vs-line-1">
                                     <div id="fw-login"class="vs-line-1-title fw-hover">
                                         <?php if(OSE_CMS =='wordpress'){ ?>
                                             <a href="admin.php?page=ose_fw_ipmanagement" style="color:white;"> <i class="fa fa-th"></i> </a>
                                         <?php }else { ?>
                                             <a href="?option=com_ose_firewall&view=ipmanagement" style="color:white;"> <i class="fa fa-th"></i> </a>
                                         <?php }?>

                                     </div>

                                     <div class="vs-line-1-number">
                                         IP Management
                                     </div>
                                 </div>
                             </div>
                         <div class="col-sm-3">
                             <div class="vs-line-1">
                                 <div id="fw-uploadvali" class="vs-line-1-title fw-hover"> <i class="fa  fa-gears"></i></div>
                                 <div class="vs-line-1-number">
                                     Advance Settings
                                 </div>
                             </div>
                         </div>
                             <div class="col-sm-3">
                                 <div class="vs-line-1">
                                     <div id="fw-wizard" class="vs-line-1-title fw-hover"> <i class="fa  fa-magic"></i></div>
                                     <div class="vs-line-1-number">
                                         Wizard
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <div class="col-sm-12" style="padding-right:20px; padding-left: 0px;">
                             <?php if($status == false){ ?>
                             <div class="title-bar" style="background:rgba(76, 53, 90, 0.6) !important;">Firewall V7 is in beta stage and is exclusively available for premium users only <br/>
                                 This service will available to free users from version 6.7.0 <br/>
                                 <b>Switch to premium users at just $99.99/Year to get an early access to Centrora's most Secure and Powerful Firewall </b></div>
                             <? }else { ?>
                                 <div class="title-bar" style="background:rgba(76, 53, 90, 0.6) !important;">Firewall V7 is in beta version, Help us to improve the quality of the product by emailing bugs at <b style="font-size: 14px;">support@centrora.com</b></div>
                             <?php }?>
                         </div>
                     </div>
                     <div id="fo-row" class="row row-set" style="padding-right: 20px;">
                         <div class="title-bar">Here is an overall view and settings of your Firewall Configuration</div>
                         <div id="fw-panel" class="col-sm-12 bg-transparent-white" style="padding-right: 0px; overflow: hidden; height: 400px;">
                             <div id="fw-off-mode-hint" class="col-sm-12" style="margin-bottom: -30px; text-align: center; margin-top: 5px;">
                                 Firewall status in currently on <b>OFF mode</b>, to activate settings, please Click ON below &nbsp;<i class="fa fa-arrow-down"></i>
                             </div>
                             <div class="col-sm-4" style="padding:50px 0px;">
                             <div class="col-sm-12 remove-padding-l-r">
                                 <div id="fw-as" onclick="toggleSettings('#fw-as','11')" class="col-sm-12 firewall-checks">
                                     <div class="shield-square"><i class="fa fa-shield"></i></div>
                                     <div class="firewall-checks-content">Anti Spam</div>
                                 </div>
                                 <div id="fw-cua" onclick="toggleSettings('#fw-cua','16')" class="col-sm-12 firewall-checks">
                                     <div class="shield-square"><i class="fa fa-shield"></i></div>
                                     <div class="firewall-checks-content">Check User Agent</div>
                                 </div>
<!--                                 <div id="fw-bp" onclick="toggleSettings('#fw-bp','15')" class="col-sm-12 firewall-checks" style="margin-top: 20px;">-->
                                 <div id="fw-bfp" class="col-sm-12 firewall-checks" style="margin-top: 20px;">
                                 <div class="shield-square"><i class="fa fa-shield"></i></div>
                                     <div class="firewall-checks-content p-t-b-10">Bruteforce protection</div>
                                 </div>
                                 <div id="fw-fuc"  class="col-sm-12 firewall-checks">
                                     <div class="shield-square"><i class="fa fa-shield"></i></div>
                                     <div class="firewall-checks-content">File upload control</div>
                                 </div>
                                 <div id="fw-srs"  class="col-sm-12 firewall-checks">
                                     <div class="shield-square"><i class="fa fa-shield"></i></div>
                                     <div class="firewall-checks-content">Scan Request Settings</div>
                                 </div>
                             </div>

                         </div>
                         <div class="col-sm-4">
                             <div class="col-sm-12 txt-center">
                                 <div id="fw-securitytag">
                                     Security<br>Level: <span id="fw-levelcount"></span> %
                                 </div>

                                 <svg version="1.1" id="mark-shield" xmlns="http://www.w3.org/2000/svg"
                                      xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="286px"
                                      height="311px" viewBox="0 0 286 311" enable-background="new 0 0 286 311"
                                      xml:space="preserve">
                                   <defs>
                                       <mask id="mask">
                                           <polygon fill="white"
                                                    points="143.705,32.138 262.554,73.118 243.826,227.782 143.705,282.861 44.218,228.222 25.821,73.889 "/>
                                       </mask>
                                       <g id="curtain">
                                           <rect id="cr-left" x="9.875" y="28.999" fill="#41B3A1" width="134.312" height="263.573"/>
                                           <rect id="cr-right" x="144.188" y="28.999" fill="#269D8A" width="138.479" height="263.573"/>
                                       </g>
                                   </defs>
                                     <polygon fill="#D7D5D3" stroke="#A9A7A5" stroke-width="8" stroke-miterlimit="10"
                                              points="143.641,15.249 278.5,61.75 257.25,237.25 143.641,299.75 30.75,237.75 9.875,62.625 "/>
                                     <polygon fill="#c9c9c9"
                                              points="143.705,32.138 143.705,282.861 243.826,227.782 262.554,73.118 "/>
                                     <g mask="url(#mask)">
                                         <use id="fill-shield" xlink:href="#curtain"/>
                                     </g>
                                </svg>

                             </div>
                         </div>
                         <div class="col-sm-4" style="padding:30px 0px 22px 15px;">
                             <div id="fw-fs-section" class="col-sm-12" style="padding-right: 0px;">
                                 <div class="bg-color-midiumgrey fs-info-sections">Firewall Status</div>
                                 <div class="fs-info-sections" style="padding-left: 30px; margin-top: -5px; margin-bottom: -5px;">
                                     <?php if($status == false){ ?>
                                         <div class="disable">OFF</div>
                                     <?php }else {?>
                                         <div id="fc-fs-on">ON</div>
                                         <div id="fc-fs-off">OFF</div>
                                     <?php }?>

                                 </div>

                                 <div class="bg-color-lightgrey fs-info-sections">Web Admin Email</div>
                                 <div class="form-group fs-info-sections" style="padding-left:27px;">
                                     <input type="text" class="form-control" id="wa-email">
                                 </div>

                                 <div class="bg-color-midiumgrey fs-info-sections">Firewall sensitivity</div>
                                 <div class="fs-info-sections" style="padding-left:38px;">
<!--                                 <input id="fwslider" type="text" data-slider-min="0" data-slider-max="4" data-slider-step="1" data-slider-value="0"/>-->
                                     <input id="fwslider" type="text" data-slider-min="0" data-slider-max="4" data-slider-step="1"/>
                                 &nbsp; &nbsp;<span id="slide-value">insensitive</span>
                                 </div>

                                 <div class="bg-color-lightgrey fs-info-sections">Model</div>
                                 <?php if($status == false){?>
                                     <div class="fs-info-sections" style="padding-left: 30px; margin-top: -5px; margin-bottom: -5px;">
                                         <div id="" class="fw-freeuser" style="margin-right:45px;" >BLOCKING</div>
                                         <div id="" class="fw-freeuser">FILTERING</div>
                                     </div>
                                 <?php }else { ?>
                                     <div class="fs-info-sections" style="padding-left: 30px; margin-top: -5px; margin-bottom: -5px;">
                                         <div id="fc-mod-block">BLOCKING</div>
                                         <div id="fc-mod-filter">FILTERING</div>
                                     </div>
                                 <?php }?>
                             </div>

                             <div id="fw-bfp-section" class="col-sm-12" style="padding-right: 0px;">
                                 <div class="bg-color-midiumgrey bfp-info-sections">Brute force protection status</div>
                                 <div class="bfp-info-sections" style="padding-left: 30px; margin-top: -5px; margin-bottom: -5px;">
                                     <div id="bfp-on">ON</div>
                                     <div id="bfp-off">OFF</div>
                                 </div>
                                <div id="bfp-belongings">
                                 <div class="bg-color-lightgrey bfp-info-sections">Maximum login attempts</div>
                                 <div class="form-group bfp-info-sections" style="padding-left:27px;">
                                     <select id="bfp-login-attempts">
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option>
                                         <option value="5">5</option>
                                         <option value="6">6</option>
                                         <option value="7">7</option>
                                         <option value="8">8</option>
                                         <option value="9">9</option>
                                         <option value="10">10</option>
                                         <option value="20">20</option>
                                         <option value="30">30</option>
                                         <option value="40">40</option>
                                         <option value="50">50</option>
                                         <option value="100">100</option>
                                         <option value="200">200</option>
                                         <option value="500">500</option>
                                     </select>
                                 </div>

                                 <div class="bg-color-lightgrey bfp-info-sections">Period for counting login attempts</div>
                                 <div class="bfp-info-sections" style="padding-left:27px;">
                                     <select id="bfp-login-period">
                                         <option value="5" selected >5 minutes</option>
                                         <option value="10">10 minutes</option>
                                         <option value="30">30 minutes</option>
                                         <option value="60">1 hour</option>
                                         <option value="120">2 hours</option>
                                         <option value="360">6 hours</option>
                                         <option value="720">12 hours</option>
                                         <option value="1440">1 day</option>
                                     </select>
                                 </div>

                                 <div class="bg-color-lightgrey bfp-info-sections">
                                     <div id="google-code-box">
                                         <span id="code-box-off">Google Authentication is currently in <b>off mode</b>, Please enable 'Google Authentication' and <b>SAVE</b> First</span>
                                        <span id="code-box-on"></span>
                                     </div>
                                     <span id="google-code">Show QR code</span>
                                     Google Verification</div>
                                 <div class="bfp-info-sections" style="padding-left: 30px; margin-top: -5px; margin-bottom: -5px;">
                                     <div id="bfp-gv-on">ON</div>
                                     <div id="bfp-gv-off">OFF</div>
                                 </div>
                             </div>
                             </div>

                             <div id="fw-srs-section" class="col-sm-12" style="padding: 0px;">
                                 <div id="fw-csrf" onclick="toggleSRSettings('#fw-csrf','3')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Cross site request forgery</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-css" onclick="toggleSRSettings('#fw-css','2')"  class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Cross site scription</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div  id="fw-si" onclick="toggleSRSettings('#fw-si','4')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">SQL Injection</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-rfi" onclick="toggleSRSettings('#fw-rfi','5')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Remote file inclusion</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-lfi" onclick="toggleSRSettings('#fw-lfi','6')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Local file inclusion</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-fsa" onclick="toggleSRSettings('#fw-fsa','12')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Format string attack</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-lfma" onclick="toggleSRSettings('#fw-lfma','10')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Local file modification attempt</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="fw-dt" onclick="toggleSRSettings('#fw-dt','8')" class="srs-info-sections col-sm-12 p-l-r-0">
                                     <div class="srs-checks-content">Directory traversal</div>
                                     <div class="srs-square"><i class="fa fa-shield"></i></div>
                                 </div>
                                 <div id="btn-srs-sa" class="col-sm-4 btn-firewall-config fw-hover srs-info-sections-btn" style="margin:5px 3px 0px -7px;">Select All</div>
                                 <div id="btn-srs-dsa" class="col-sm-4 btn-firewall-config fw-hover srs-info-sections-btn" style=" margin-top: 5px; margin-right: 3px;">Deselect All</div>
                                 <div id="btn-srs-close" class="col-sm-4 btn-firewall-config fw-hover srs-info-sections-btn" style=" margin-top: 5px;">Close</div>
                             </div>
                             <div id="fw-fuc-section" class="col-sm-12" style="padding: 0px;">
                                 <div  class="fuc-info-sections col-sm-12 p-l-r-0">
                                     <div id="fw-vuf" onclick="toggleFUCSettings('#fw-vuf','13')" class="fuc-checks-content">Validate Upload Files</div>
                                     <a id="question-vuf" class="fuc-square" href="#" title=" Validate Upload Files" data-toggle="popover" data-placement="left" data-content="Centrora Security™ Firewall protects against untrusted file uploads. Use this list to add exceptions (e.g. jpg, png, doc) *Please note: FILEINFO module needs to be installed and configured properly.">
                                         <i id="question-vuf" class="fw-question-icons fa fa-question"></i>
                                     </a>
                                     <!--                                     <div class="fuc-square"><i class="fa fa-question"></i></div>-->
                                 </div>
                                 <div  class="fuc-info-sections col-sm-12 p-l-r-0">
                                     <div id="fw-svf"  onclick="toggleFUCSettings('#fw-svf','14')" class="fuc-checks-content">Scan Varius Files</div>
                                     <a id="question-svf" class="fuc-square" href="#" title="Scan Virus Files" data-toggle="popover"  data-content="Centrora Security Firewall utilize the built-in malware scanner to scan all uploaded files for malicious codes. Any uploaded malware will be blocked immedialy once detected.">
                                         <i class="fw-question-icons fa fa-question"></i>
                                     </a>
<!--                                     <div class="fuc-square"><i class="fa fa-question"></i></div>-->
                                 </div>
                                 <div id="btn-fuc-sa" class="col-sm-4 btn-firewall-config fw-hover fuc-info-sections-btn" style="margin:5px 3px 0px -7px;">Select All</div>
                                 <div id="btn-fuc-dsa" class="col-sm-4 btn-firewall-config fw-hover fuc-info-sections-btn" style=" margin-top: 5px; margin-right: 3px;">Deselect All</div>
                                 <div id="btn-fuc-close" class="col-sm-4 btn-firewall-config fw-hover fuc-info-sections-btn" style=" margin-top: 5px;">Close</div>
                             </div>
                         </div>
                     </div>
                         <div class="col-sm-12">
                             <?php if($status == false){ ?>
                                 <div id="fw-submit" class="pull-right col-sm-4 btn-new result-btn-set disable" style="margin-right: -15px; margin-top: 15px; text-align: center;"><i id="ic-change" class="fa fa-save text-primary" style="margin-right: 5px;"></i>Save</div>
                                 <div id="save-hint" class="pull-right pumpAnimation" style="font-size: 14px; margin-right: 25px; font-weight: 400; display: none; color: white; margin-top: 19px;">
                                     Please click save button here to save your changed settings &nbsp;&nbsp;<i class="fa  fa-arrow-right"></i>
                                 </div>
                             <?php }else {?>
                                 <div id="fw-submit" class="pull-right col-sm-4 btn-new result-btn-set " style="margin-right: -15px; margin-top: 15px; text-align: center;"><i id="ic-change" class="fa fa-save text-primary" style="margin-right: 5px;"></i>Save</div>
                                 <div id="save-hint" class="pull-right pumpAnimation" style="font-size: 14px; margin-right: 25px; font-weight: 400; display: none; color: white; margin-top: 19px;">
                                     Please click save button here to save your changed settings &nbsp;&nbsp;<i class="fa  fa-arrow-right"></i>
                                 </div>
                             <?php }?>
                         </div>
                     </div>

                     <!--   Here is the HTML for file upload validation-->
                     <div id="uv-row" class="row row-set" style="padding-right: 20px;">
                         <div class="title-bar">Here to view and set up advanced features</div>
                         <div class="col-sm-3 bg-transparent-white" style="padding-bottom: 170px;">

                             <div class="upload-btn-frame txt-center" style="margin-top:30px;">
                                 <div id="btn-se-config" class="upload-btns"  style="width:99%;">SEO Configuration</div>
                             </div>
<!--                             <div class="exp-header">Click to View and operate tables</div>-->
                             <div class="upload-btn-frame txt-center">
                                 <div class="upload-btns" id="upload-ful">File Upload Logs</div>
                                 <a id="question-ful" class="fuc-square" href="#" title="Scan Virus Files" data-toggle="popover" data-content="This panel shows the the list of files with invalid file types or malware."
                                 style="width:15%; height:42px;">
                                 <i class="fw-question-icons fa fa-question"></i>
                                 </a>
                             </div>
                             <div class="upload-btn-frame txt-center">
                             <div id="btn-switch-table" class="col-sm-11 upload-btns" style="width:99%;">
                                 File extension control table</div>
                             </div>
                             <div class="upload-btn-frame txt-center">
                                 <?php if(OSE_CMS =='wordpress'){ ?>
                                 <a href="admin.php?page=ose_fw_whitemgmt" style="color:white;">
                                     <?php }else { ?>
                                     <a href="?option=com_ose_firewall&view=whitelistmgmt" style="color:white;">
                                         <?php }?>
                                         <div  class="col-sm-11 upload-btns" style="width:99%;">
                                     White list management</div>
                                     </a>
                             </div>
                             <div class="upload-btn-frame txt-center">
                                 <?php if($status == false){?>
                                     <div  style="color:white;">
                                         <div  class="fw-freeuser col-sm-11 upload-btns" style="width:99%;">
                                             Country Blocking</div>
                                     </div>
                                 <?php }else { ?>
                                 <?php if(OSE_CMS =='wordpress'){ ?>
                                 <a href="admin.php?page=ose_fw_countryblockingv7" style="color:white;">
                                     <?php }else { ?>
                                     <a href="?option=com_ose_firewall&view=countryblockingv7" style="color:white;">
                                         <?php }?>

                                         <div  class="col-sm-11 upload-btns" style="width:99%;">
                                             Country Blocking</div>
                                     </a>
                                 <?php }?>

                             </div>
                             <div class="upload-btn-frame txt-center">
                                 <?php if(OSE_CMS =='wordpress'){ ?>
                                 <a href="admin.php?page=ose_fw_auditv7" style="color:white;">
                                     <?php }else { ?>
                                     <a href="?option=com_ose_firewall&view=auditv7" style="color:white;">
                                         <?php }?>
                                         <div  class="col-sm-11 upload-btns" style="width:99%;">
                                        Audit My Website</div>
                                 </a>
                             </div>
                             <div class="upload-btn-frame txt-center">
                                 <?php if(OSE_CMS =='wordpress'){ ?>
                                 <a href="admin.php?page=ose_fw_banpagemgmt" style="color:white;">
                                     <?php }else { ?>
                                     <a href="?option=com_ose_firewall&view=banpagemgmt" style="color:white;">
                                         <?php }?>
                                         <div  class="col-sm-11 upload-btns" style="width:99%;">
                                        Ban Page Management</div>
                                 </a>
                             </div>
                         </div>
                         <div class="col-sm-9" style="padding: 0px;">
                             <div id="adset-tablehints">Plesase enable <b>Validate Upload files</b> setting in <b>'Firewall Overview'</b> page, then you can access this table. </div>
                             <div id="vuf-table" class="col-sm-12 disable-pointer turnBlur" style="padding:0px">
                                 <div class="fuv-table-btn-frame">
                                     <button class="btn-new fw-hover fuv-table-btns" onClick="addExt()" type="button">
                                         <i class="fa fa-plus"></i>
                                         Add file extension
                                     </button>
                                 </div>
                                 <table class="table display" id="extensionListTable">
                                     <thead>
                                     <tr>
                                         <th><?php oLang::_('O_EXTENSION_ID'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_NAME'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_TYPE'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_STATUS'); ?></th>
                                     </tr>
                                     </thead>
                                     <tfoot>
                                     <tr>
                                         <th><?php oLang::_('O_EXTENSION_ID'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_NAME'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_TYPE'); ?></th>
                                         <th><?php oLang::_('O_EXTENSION_STATUS'); ?></th>
                                     </tr>
                                     </tfoot>
                                 </table>
                             </div>
                             <div id="ful-table" class="col-sm-12 disable-pointer turnBlur" style="padding:0px">
                                 <table class="table display" id="uploadLogTable">
                                     <thead>
                                     <tr>
                                         <th><?php oLang::_('O_ID'); ?></th>
                                         <th><?php oLang::_('O_START_IP'); ?></th>
                                         <th><?php oLang::_('O_FILENAME'); ?></th>
                                         <th><?php oLang::_('O_FILETYPE'); ?></th>
                                         <th><?php oLang::_('O_IP_STATUS'); ?></th>
                                         <!--                                                    <th>--><?php //oLang::_('O_VSSCAN_STATUS'); ?><!--</th>-->
                                         <th><?php oLang::_('O_DATE'); ?></th>
                                     </tr>
                                     </thead>
                                     <tfoot>
                                     <tr>
                                         <th><?php oLang::_('O_ID'); ?></th>
                                         <th><?php oLang::_('O_START_IP'); ?></th>
                                         <th><?php oLang::_('O_FILENAME'); ?></th>
                                         <th><?php oLang::_('O_FILETYPE'); ?></th>
                                         <th><?php oLang::_('O_IP_STATUS'); ?></th>
                                         <!--                                                    <th>--><?php //oLang::_('O_VSSCAN_STATUS'); ?><!--</th>-->
                                         <th><?php oLang::_('O_DATE'); ?></th>
                                     </tr>
                                     </tfoot>
                                 </table>
                             </div>
<!--                             SEO CONIG FORM BEGINS-->
                             <div id="seo-sets" class="col-sm-12" style="background:rgba(255, 255, 255, 0.7);">
                                 <form id = 'seo-configuraton-formv7' class="form-horizontal group-border stripped" role="form">
                                     <div class="form-group">
                                         <label for="pageTitle" class="col-sm-4 control-label"><?php oLang::_('O_SEO_PAGE_TITLE');?>
                                             <i tabindex="0" class="fa fa-question-circle color-gray"  data-toggle="popover"
                                                data-content="<?php oLang::_('O_SEO_PAGE_TITLE_HELP');?>"></i>
                                         </label>
                                         <div class="col-sm-8">
                                             <input type="text" name="pageTitle" value="<?php echo (empty($seoConfArray['info'][18]))?'Your Web Page Title':$seoConfArray['info'][18]?>" class="form-control">
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label for="metaKeywords" class="col-sm-4 control-label"><?php oLang::_('O_SEO_META_KEY');?>
                                             <i tabindex="0" class="fa fa-question-circle color-gray"  data-toggle="popover"
                                                data-content="<?php oLang::_('O_SEO_META_KEY_HELP');?>"></i>
                                         </label>
                                         <div class="col-sm-8">
                                             <input type="text" name="metaKeywords" value="<?php echo (empty($seoConfArray['info'][19]))?'SEO Meta Keywords':$seoConfArray['info'][19]?>" class="form-control">
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label"><?php oLang::_('O_SEO_META_DESC');?>
                                             <i tabindex="0" class="fa fa-question-circle color-gray"  data-toggle="popover"
                                                data-content="<?php oLang::_('O_SEO_META_DESC_HELP');?>"></i>
                                         </label>
                                         <div class="col-sm-8">
                                             <input type="text" name="metaDescription" value="<?php echo (empty($seoConfArray['info'][20]))?'SEO Meta Description':$seoConfArray['info'][20]?>" class="form-control">
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label"><?php oLang::_('O_SEO_META_GENERATOR');?>
                                             <i tabindex="0" class="fa fa-question-circle color-gray"  data-toggle="popover"
                                                data-content="<?php oLang::_('O_SEO_META_GENERATOR_HELP');?>"></i>
                                         </label>
                                         <div class="col-sm-8">
                                             <input type="text" name="metaGenerator" value="<?php echo (empty($seoConfArray['info'][21]))?'SEO Meta Generator':$seoConfArray['info'][21]?>" class="form-control">
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label"><?php oLang::_('O_SCAN_GOOGLE_BOTS');?></label>
                                         <div class="col-sm-8">
                                             <div class="onoffswitch">
                                                 <input type="checkbox" value = 1 name="scanGoogleBots" class="onoffswitch-checkbox" id="scanGoogleBots"
                                                     <?php echo (!empty($seoConfArray['info'][22]) && $seoConfArray['info'][22]) ? 'checked="checked"' : '' ?>>
                                                 <label class="onoffswitch-label" for="scanGoogleBots">
                                                     <span class="onoffswitch-inner"></span>
                                                     <span class="onoffswitch-switch"></span>
                                                 </label>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label"><?php oLang::_('O_SCAN_YAHOO_BOTS');?></label>
                                         <div class="col-sm-8">
                                             <div class="onoffswitch">
                                                 <input type="checkbox" value = 1 name="scanYahooBots" class="onoffswitch-checkbox" id="scanYahooBots"
                                                     <?php echo (!empty($seoConfArray['info'][23]) && $seoConfArray['info'][23] == true) ? 'checked="checked"' : '' ?>>
                                                 <label class="onoffswitch-label" for="scanYahooBots">
                                                     <span class="onoffswitch-inner"></span>
                                                     <span class="onoffswitch-switch"></span>
                                                 </label>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="form-group">
                                         <label class="col-sm-4 control-label"><?php oLang::_('O_SCAN_MSN_BOTS');?></label>
                                         <div class="col-sm-8">
                                             <div class="onoffswitch">
                                                 <input type="checkbox" value = 1 name="scanMsnBots" class="onoffswitch-checkbox" id="scanMsnBots"
                                                     <?php echo (!empty($seoConfArray['info'][24]) &&$seoConfArray['info'][24] == true) ? 'checked="checked"' : '' ?>>
                                                 <label class="onoffswitch-label" for="scanMsnBots">
                                                     <span class="onoffswitch-inner"></span>
                                                     <span class="onoffswitch-switch"></span>
                                                 </label>
                                             </div>
                                         </div>
                                     </div>
                                     <input type="hidden" name="option" value="com_ose_firewall">
                                     <input type="hidden" name="controller" value="bsconfigv7">
                                     <input type="hidden" name="action" value="saveConfigSEO">
                                     <input type="hidden" name="task" value="saveConfigSEO">
                                     <input type="hidden" name="type" value="seo">

                                     <div class="form-group">
                                         <div class="col-sm-offset-10">
                                             <button type="submit" class="btn-new result-btn-set" id='save-button'><?php oLang::_('SAVE');?></button>
                                         </div>
                                     </div>
                                 </form>
                             </div>
                             <!--                         seo config form ends-->
                         </div>
                     </div>
                                            <!--          uv row end-->
                     <div id="wizard-row" class="row row-set" style="padding-right: 20px;">
                         <div class="title-bar">Easy set up here for Firewall Configuration</div>
                         <div id="wiz-basic" class="col-sm-12 bg-transparent-white" style="padding-bottom: 30px; min-height: 345px;">
                            <div class="wizard-nav">
                                <ul>
                                    <li id="li-bfp" class="opacity-100">Brute Force</li>
                                    <li id="li-bfp-set">Brute Force setups</li>
                                    <li id="li-as">Anti Spamming</li>
                                    <li id="li-fup">File Upload Protection</li>
                                    <li id="li-rs">Request Scanning</li>
                                    <li id="li-email">Email and Firewall Sensitity</li>
                                    <li id="li-block">Block & Filter</li>
                                    <li id="li-complete">Complete</li>
                                </ul>
                            </div>
                             <div id="wiz-bfp">
                                 <div class="col-sm-12 wizard-section-header">
                                     Brute Force Protection
                                 </div>
                                 <div class="wizard-section-content">
                                     Hacker and bots can attack your websites by guessing or trying out various
                                     combination of username and password, protect your website by enabling this
                                     feature.
                                 </div>
                             </div>
                             <div id="wiz-bfp-set">
                                 <div class="col-sm-12 wizard-section-header">
                                     Brute Force Protection Setups
                                 </div>
                                 <div class="wizard-section-content">
                                     <div class="col-sm-12">
                                         Please select the attempts threshold after which an  attacker will be blocked :
                                         <select id="bfp-wiz-attempts" class="col-sm-12">
                                             <option value="1">1</option>
                                             <option value="2">2</option>
                                             <option value="3">3</option>
                                             <option value="4">4</option>
                                             <option value="5">5</option>
                                             <option value="6">6</option>
                                             <option value="7">7</option>
                                             <option value="8">8</option>
                                             <option value="9">9</option>
                                             <option value="10">10</option>
                                             <option value="20">20</option>
                                             <option value="30">30</option>
                                             <option value="40">40</option>
                                             <option value="50">50</option>
                                             <option value="100">100</option>
                                             <option value="200">200</option>
                                             <option value="500">500</option>
                                         </select>
                                     </div>
                                     <div class="col-sm-12" style="margin-top: 10px;">
                                         Please select the time frame for which the the tracks will be tracked,
                                         If the number of attacks performed by attacker in the selected time exceeds
                                         the threshold, he/she will be blocked:
                                         <select id="bfp-wiz-period" class="col-sm-12">
                                             <option value="5" selected >5 minutes</option>
                                             <option value="10">10 minutes</option>
                                             <option value="30">30 minutes</option>
                                             <option value="60">1 hour</option>
                                             <option value="120">2 hours</option>
                                             <option value="360">6 hours</option>
                                             <option value="720">12 hours</option>
                                             <option value="1440">1 day</option>
                                         </select>
                                     </div>
                                     <div class="col-sm-12" style="margin-top: 10px;">
                                        <b>Google Authentication</b>
                                         <i id="gv-desc" class="fa  fa-question-circle"></i>
                                         <img id="wiz-gaimage-1" class="col-sm-12 gv-image-desc" alt="how it works" src="http://image.slidesharecdn.com/two-factorauthenticationallthingsapimeetup-150624094258-lva1-app6891/95/two-factor-authentication-with-laravel-and-google-authenticator-3-638.jpg?cb=1435139034">
                                         <img id="wiz-gaimage-2" class="col-sm-12 gv-image-desc" alt="how it works" src="https://d35q8ug2n7npkr.cloudfront.net/qr_firewallset.png">
                                         <img id="wiz-gaimage-3" class="col-sm-12 gv-image-desc" alt="how it works" src="https://d35q8ug2n7npkr.cloudfront.net/qr_userprofile.png">

                                         will heavily guard your website against the brute force attacks.To
                                         use this feature please download the Google Authentication app from the app
                                         store and scan the QR Code from the user page of the website.Use the code from
                                         the mobile application to sign into the website.
                                       <div class="col-sm-12">
<!---->
<!--                                         <div class="" id="bfp-wiz-gv-on">ON</div>-->
<!--                                         <div class="col-sm-6" id="bfp-wiz-gv-off">OFF</div>-->
                                           </div>
                                     </div>
                                 </div>
                             </div>
                             <div id="wiz-as">
                                 <div class="col-sm-12 wizard-section-header">
                                     Anti Spamming
                                 </div>
                                 <div class="wizard-section-content">
                                     There are numberous infected bots out there which might try to access your
                                     website and slow down the website by bombarding the website with malicious
                                     requests, block this spammers by enabling this feature and provide faster services
                                     to your customers by improving the speed of your website.
                                 </div>
                             </div>
                             <div id="wiz-fup">
                                 <div class="col-sm-12 wizard-section-header">
                                    File Upload Protection
                                 </div>
                                 <div class="wizard-section-content">
                                     According to our experts, the easiest way to hack a website is by uploading a
                                     malicious file to the website. Leave this tedious work to Centrora and we will make
                                     sure no malicious files are uploaded to your website.
                                 </div>
                             </div>
                             <div id="wiz-rs">
                                 <div class="col-sm-12 wizard-section-header">
                                     Request Scanning [Highly Recommended]
                                 </div>
                                 <div class="wizard-section-content">
                                     This feature basically act as an anti virus for your website and detects all the malicious requests sent by the users. This feature will protect your websites against attacks like:
                                     <ul class="wiz-srs-ul">
                                     <li>Cross site scripting</li>
                                     <li>Cross site request forgery</li>
                                     <li>Sql injection</li>
                                     <li>Remote file inclusion</li>
                                     <li>Local file inclusion</li>
                                     <li>Directory traversal</li>
                                     <li>Local file modification attempt</li>
                                     <li>Format String Attack</li>
                                         <li>Check user agent</li>
                                     </ul>
                                     <div style="clear:both;">
                                         Enable this feature and make your website secure against malicious requests.
                                     </div>
                                 </div>
                             </div>
                             <div id="wiz-email">

                                 <div class="col-sm-12 wizard-section-header">
                                     Set email address to receive statistics of your website.
                                 </div>
                                 <div class="wizard-section-content">
                                     Please enter your email address, Centrora will send detailed statistics related to
                                     the security of the website along with the graphs to the email address provided.
                                 </div>
                                 <div style="text-align: center;">
                                     <input type="text" id="wiz-email-address" class="form-control">
                                 </div>

                                 <div class="col-sm-12 wizard-section-header" style="margin-top: 20px;">
                                     Firewall Sensitivity
                                 </div>
                                 <div class="wizard-section-content">
                                     The system calculates the score of the attack based on the request from the users, firewall sensitivity helps the system to set a threshold till which it will provide the services to the users.
                                    <b> Warning: </b> Higher sensitivity will have a higher chance of blocking an user with low attack score
                                 </div>
                                 <div class="col-sm-12" style="text-align: center; margin-top: 10px;">
                                     <div class="wiz-sensitivity-label col-sm-2 col-sm-offset-1">
                                         Insensitive<br><input type="radio" name="sensitivity" value="90" checked>
                                     </div>
                                     <div class="wiz-sensitivity-label col-sm-2">
                                         Moderate<br><input type="radio" name="sensitivity" value="45">
                                     </div>
                                     <div class="wiz-sensitivity-label col-sm-2">
                                         Sensitive<br><input type="radio" name="sensitivity" value="35">
                                     </div>
                                     <div class="wiz-sensitivity-label col-sm-2">
                                         very sensitive<br><input type="radio" name="sensitivity" value="25">
                                     </div>
                                     <div class="wiz-sensitivity-label col-sm-2">
                                         highly sensitive<br><input type="radio" name="sensitivity" value="15">
                                     </div>

                                 </div>

                             </div>
                             <div id="wiz-block">
                                 <div class="col-sm-12 wizard-section-header">
                                     Firewall Mode
                                 </div>
                                 <div class="wizard-section-content">
                                     <?php if($status == true){?>
                                     We provide two modes for the firewall:
                                     <table class="table display dataTable">
                                         <thead style="background:rgba(250,250,250,0.7);">
                                         <tr>
                                         <th>Block Mode [premium] </th>
                                         <th>Filter Mode [premium]</th>
                                         </tr>
                                         </thead>
                                         <tbody>
                                         <tr>
                                             <td>Sanitise the malicious request</td>
                                             <td>Sanitise the malicious request </td>
                                         </tr>
                                         <tr>
                                             <td>Blocks an user if the attack score exceeds the threshold</td>
                                             <td>Does not blocks an user instead keeps on filtering the request</td>
                                         </tr>
                                         </tbody>
                                         </table>
                                     <br/>
                                     Click on the Enable Button to enable the BLOCK MODE or the Disable Button to enable FILTER MODE

                                     <?php }else { ?>
                                         We provide three modes for the firewall:
                                         <table class="table display dataTable">
                                             <thead style="background:rgba(250,250,250,0.7);">
                                             <tr>
                                                 <th style="opacity:0.6">Block Mode [Premium user only] </th>
                                                 <th style="opacity:0.6">Filter Mode [Premium user only]</th>
                                                 <th>Logging Mode [Free]</th>
                                             </tr>
                                             </thead>
                                             <tbody>
                                             <tr>
                                                 <td style="opacity:0.6">Sanitise the malicious request</td>
                                                 <td style="opacity:0.6">Sanitise the malicious request</td>
                                                 <td>Does not sanitise the malicious request</td>
                                             </tr>
                                             <tr>
                                                 <td style="opacity:0.6">Blocks an user if the attack score exceeds the threshold</td>
                                                 <td style="opacity:0.6">Does not blocks an user instead keeps on filtering the request</td>
                                                 <td>Does not blocks nor filters the request</td>
                                             </tr>
                                             </tbody>

                                         </table>
                                         <br/>
                                         Click on  <b>Enable Button</b> to enable  <b>Loggin MODE</b>
<!--                                         subscription code -->
                                     <?php }?>
                                 </div>
                             </div>
                             <div id="wiz-com">
                                 <div class="col-sm-12 wizard-section-header">
                                     Congratulations you have completed the basic settings for your website
                                 </div>
                                 <div class="wizard-section-content">
                                     Not satisfied with just the basic settings, Do you want to make you website absolutely impenetrable to the hackers.Please click on the Advanced Settings button to continue the wizard.<br><span style="opacity: 0.7;">(Warning : if you click on the save basic settings, the advanced options for the settings will be disabled)</span>
                                 </div>
                                 <div style="text-align: center; margin-top: 40px;">
                                 <div id="wiz-complete" class="btn-new">Save Basic Settings</div>
                                 <div id="wiz-go-advance" class="btn-new">Go to advance settings</div>
                                 </div>
                             </div>
                             <div id="wiz-step" class="col-sm-10" style="text-align: right; margin-top: 25px;">Step 1/9</div>
                         </div>

<!--                         here are the panel of wizard advance settings-->
                         <div id="wiz-advance" class="col-sm-12 bg-transparent-white" style="padding-bottom: 30px; min-height: 345px;">
                             <div class="wizard-nav">
                                 <ul>
                                     <li id="ad1-title" class="opacity-100">White List</li>
                                     <li id="ad2-title">Search engine</li>
                                     <li id="ad3-title">Complete Advance settings</li>
                                 </ul>
                             </div>

                             <div id="wiz-ad-1" class="col-sm-12">
                                 <div class="col-sm-12 wizard-section-header">
                                     Advance Settings: Choose Whitelist String and Variables
                                 </div>
                                 <div class="wizard-section-content" style="text-align:center;">
                                     This feature will not scan the variables or strings that are marked as whitelisted and will reduce the false alerts
                                 </div>
                                 <div class="col-sm-offset-3 col-sm-6" style="text-align: center; margin-top: 40px;">
                                     <?php $v6variableexists = $this->model->v6variablesexists();?>
                                     <? if($v6variableexists['status'] == 'SUCCESS' ) {?>
                                     <div id="wiz-ad1-imp" class="btn-new">Migrate Whitelisted Variables from Firewall Scanner Version 6</div>
                                     <?php }?>
                                     <div id="wiz-ad1-def" class="btn-new" style="margin-top: 5px;">Use default whitelisted string and variables</div>
                                     <div id="wiz-ad1-skip" class="btn-new" style="margin-top: 5px;">Skip</div>
                                 </div>
                             </div>
                             <div id="wiz-ad-2"  class="col-sm-12">
                                 <div class="col-sm-12 wizard-section-header">
                                     Advance Settings: Search Engine Bots Scanning
                                 </div>
                                 <div class="wizard-section-content" style="text-align:center;">
                                     Hackers can pretend to be search engine bots and might try to access services from your websites.By default the system will not scan the request from bots for malicious request , you can increase the security level by enabling the search engine bots scanning.
                                 </div>
                                 <div class="col-sm-offset-3 col-sm-6" style="text-align: center; margin-top: 40px;">
                                     <div id="wiz-ad2-enable" class="btn-new">Enable</div>
                                     <div id="wiz-ad2-skip" class="btn-new" style="margin-top: 5px;">Skip</div>
                                 </div>
                             </div>
                             <div id="wiz-ad-3"  class="col-sm-12">
                                 <div class="col-sm-12 wizard-section-header">
                                     Congratulation the firewall setup wizard has been completed
                                 </div>
                                 <div class="wizard-section-content" style="text-align:center;">
                                     The firewall provides a high level of customisation to its user.
                                     <ol style="text-align:left;">
                                         <li><b>Country Blocking</b>: This feature will allow you to block  users from certain countries.</li>
                                         <li><b>File Upload Management</b>: This feature allows you to restrict the file types that can be uploaded by the user.</li>
                                         <li><b>Ban page Customisation</b>: This feature allows you to design a custom ban page which will be visible to the users who are banned.</li>
                                     <ol>
                                 </div>
                                 <div class="col-sm-offset-3 col-sm-6" style="text-align: center; margin-top: 40px;">
                                     <div id="wiz-ad3-fin" class="btn-new">Finish</div>
                                 </div>
                             </div>
                         </div>
<!--                         here are the button for wizard basic settings-->
                         <div id="wiz-btns" class="col-sm-12" style="float:right; margin-top: 15px; padding-right: 20px;">
                             <div id="wiz-skip" class="btn-new result-btn-set p-l-r-20">Skip</div>
                             <div id="wiz-enable" class="btn-new result-btn-set p-l-r-20">Enable</div>
                             <div id="wiz-disable" class="btn-new result-btn-set p-l-r-20">Disable</div>
                             <div id="wiz-back" class="btn-new result-btn-set p-l-r-20">Back</div>
                         </div>
                     </div>

                     <div class="row row-set" style="margin-top:14px;">
                         <div class="col-sm-12" style="padding-left: 0px; padding-right: 20px;">
                             <a href="http://www.centrora.com/developers/" target="_blank"><div class="call-to-action">
                                     <div class="call-to-action-txt">
                                         <img width="35" height="35" alt="C_puma" src="http://googledrive.com/host/0BzcQR8G4BGjUX0ZzTzBvUVNEb00"> &nbsp;
                                         Schedule your scanning and update with Centrora Premium <sup>Now</sup></div>
                                 </div></a>
                         </div>

                     </div>
                     <div class="row">
                         <div id="footer" class="col-sm-12">
                             <div>Centrora 2016 a portfolio of Luxur Group PTY LTD,  All rights reserved.</div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
</div>

<div class="modal fade" id="addExtModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel2"><?php oLang::_('ADD_EXT'); ?></h4>
            </div>
            <form id='addext-form' class="form-horizontal group-border stripped" role="form">
                <div class="modal-body">
                    <div class="form-group">
                        <label
                            class="col-sm-4 control-label"><?php oLang::_('O_EXTENSION_NAME'); ?></label>

                        <div class="col-sm-8">
                            <input type="text" name="ext-name" value="" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="ext-type"
                               class="col-sm-4 control-label"><?php oLang::_('O_EXTENSION_TYPE'); ?></label>

                        <div class="col-sm-8">
                            <select class="form-control" name='ext-type' id='ext-type'>
                                <?php print_r($this->model->getExtType()) ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="ext-status"
                               class="col-sm-4 control-label"><?php oLang::_('O_EXTENSION_STATUS'); ?></label>

                        <div class="col-sm-8">
                            <select class="form-control" name='ext-status' id='ext-status'>
                                <option value='1'>Allowed</option>
                                <option value='2'>Forbidden</option>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="option" value="com_ose_firewall">
                    <input type="hidden" name="controller" value="upload">
                    <input type="hidden" name="action" value="saveExt">
                    <input type="hidden" name="task" value="saveExt">
                </div>
                <div class="modal-footer">
                    <label id="ext-warning-label" class="col-sm-6 control-label" style="display: none"><i
                            id="ext-warning-message" class="fa fa-exclamation-triangle" style="display: none"></i></label>

                    <div id="buttonDiv">
                        <div class="form-group">
                            <button type="submit" class="btn-new pull-right"><i
                                    class="glyphicon glyphicon-save"></i> <?php oLang::_('SAVE'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


