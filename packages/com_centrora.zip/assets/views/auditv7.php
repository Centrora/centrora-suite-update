<?php
/**
 * Created by PhpStorm.
 * User: suraj
 * Date: 21/07/2016
 * Time: 2:35 PM
 */
oseFirewall::checkDBReady ();
$this->model->getNounce();
$urls = oseFirewall::getDashboardURLs();
$confArray = $this->model->getConfiguration('scan');
$seoConfArray = $this->model->getConfiguration('seo');
?>
    <div id = "oseappcontainer" >
        <div class="container wrapbody">
            <?php
            $this ->model->showLogo ();
            ?>
            <!-- Row Start -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel-body wrap-container">

                        <div class="row row-set">
                            <div class="col-sm-3 p-l-r-0">
                                <div id="c-tag">
                                    <div class="col-sm-12" style="padding-left: 0px;">
                                        <span class="tag-title">Firewall Configuration</span>
                                        <span>(Audit My website)</span>
                                    </div>
                                    <p class="tag-content">Auditing my website here, this features will be renovated and improved in next version.</p>
                                </div>
                            </div>
                            <div class="col-sm-9">
                                <div class="col-sm-11">
                                    <div class="vs-line-1">
                                        <div id="fw-overview" class="vs-line-1-title fw-hover">
                                            <?php if(OSE_CMS =='wordpress'){ ?>
                                                <a href="admin.php?page=ose_fw_bsconfigv7" style="color:white;"><i class="fa fa-fire"></i></a>
                                            <?php }else { ?>
                                                <a href="?option=com_ose_firewall&view=bsconfigv7" style="color:white;"> <i class="fa fa-fire"></i> </a>
                                            <?php }?>
                                        </div>
                                        <div class="vs-line-1-number">
                                            Back to Firewall Overview
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row row-set">
                            <div class="title-bar">Auditing my website.</div>
                            <div class="col-sm-12 bg-transparent-white">
                                <?php
                                if ($this->model->isBadgeEnabled()==false)
                                {
                                    ?>
                                    <!-- Panels Start -->
                                    <div class="panel panel-teal">
                                        <div class="panel-heading">
                                            <h3 class="panel-title color-dark"><?php echo 'Security Badge Disabled'; ?></h3>
                                        </div>
                                        <div class="panel-body">
                                            <ul class="list-group">
                                                <li class="list-group-item">
                                                    <div class="col-sm-10">
                                                    <span class="label label-warning">Note</span> <?php oLang::_('SECURITY_BADGE_DESC'); ?>
                                                    </div>
                                                    <div class="col-sm-2">
                                                    <a class="btn-new result-btn-set" href="<?php echo OSE_WPURL . '/wp-admin/widgets.php';?>" target="_blank">Fix it</a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- Panels Ends -->
                                    <?php
                                }
                                ?>

                                <!-- Panels Start -->
                                <div class="panel panel-teal">
                                    <div class="panel-heading">
                                        <h3 class="panel-title color-dark"><?php echo SAFE_BROWSING_CHECKUP; ?></h3>
                                    </div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <?php
                                            $this ->model->showSafeBrowsingBar ();
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Panels Ends -->
                                <!-- Panels Start -->
                                <div class="panel panel-teal">
                                    <div class="panel-heading">
                                        <h3 class="panel-title color-dark"><?php echo SECURITY_CONFIG_AUDIT; ?></h3>
                                    </div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <?php
                                            $this ->model->showStatus ();
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Panels Ends -->
                                <!-- Panels Start -->
                                <div class="panel panel-teal">
                                    <div class="panel-heading">
                                        <h3 class="panel-title color-dark"><?php echo SYSTEM_SECURITY_AUDIT; ?></h3>
                                    </div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <?php
                                            $this ->model->showSytemStatus ();
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                                <!-- Panels Ends -->

                                <!-- Panels Start -->
                                <!--		  <div class="panel panel-teal">-->
                                <!--			  <div class="panel-heading">-->
                                <!--				  <h3 class="panel-title">--><?php //echo WORDPRESS_FOLDER_PERMISSIONS ?><!--</h3>-->
                                <!--			  </div>-->
                                <!--			  <div class="panel-body">-->
                                <!--				  <ul class="list-group">-->
                                <!--					  --><?php
                                //					  if(OSE_CMS =='wordpress') {
                                //						  echo $this->model->checkfolderPermission('wp-admin');
                                //						  echo $this->model->checkfolderPermission('wp-content');
                                //						  echo $this->model->checkfolderPermission('wp-includes');
                                //						  echo $this->model->checkHtaccessFile('wp-content');
                                //						  echo $this->model->checkHtaccessFile('wp-includes');
                                //						  echo $this->model->checkHtaccessFile('uploads');
                                //					  }
                                //					  elseif(OSE_CMS=='joomla')
                                //					  {
                                //						  //code for joomla;
                                //					  }?>
                                <!--				  </ul>-->
                                <!--			  </div>-->
                                <!--		  </div>-->
                                <!-- Panels Ends -->
                                <!-- Panels Ends -->

                            </div>
                        </div>

                        </div>
                </div>
            </div>
            <!-- Row Ends -->
        </div>
    </div>
    <div id='fb-root'></div>
<?php
//\PHPBenchmark\Monitor::instance()->snapshot('Finish loading Centrora');
?>

<?php
include_once(dirname(__FILE__).'/scanconfig.php');
include_once(dirname(__FILE__).'/adminform.php');
include_once(dirname(__FILE__).'/phpconfig.php');
?>