<?php
/**
 * Created by PhpStorm.
 * User: zhuhua
 * Date: 14/08/15
 * Time: 11:22 AM
 */

?>
<div class="updated" style="padding: 2px; border-radius: 5px 5px 5px 5px">
    <div style="border-radius: 5px 5px 5px 5px;
         -moz-border-radius: 56px 56px 56px 56px;
         -webkit-border-radius: 56px 56px 56px 56px;
         height: 20px !important;
         background-color: white;"
        >
        <div class="notice-header" style="border: 0; color:#0047AB; font-size: 1.2em;"> Centrora protect you from <a href = "#"><strong style="color:#F5B041">10</strong></a> vulnerabilities.</div>
    </div>
    </div>