<!-- Form Modal -->
                <div class="modal fade" id="filecontentModal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                                </button>
                                <div class="modal-title" id="headerpathDiv"></div>
                            </div>
                            <div class="modal-body">
								<div id="codeareaDiv"></div>
                              </div>
                            <div class="modal-footer">
                                <div id="buttonDiv">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
	<!-- /.modal -->