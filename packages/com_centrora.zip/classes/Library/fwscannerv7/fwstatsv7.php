<?php
/**
 * Created by PhpStorm.
 * User: suraj
 * Date: 20/07/2016
 * Time: 2:21 PM
 */
if (!defined('OSE_FRAMEWORK') && !defined('OSEFWDIR') && !defined('_JEXEC'))
{
    die('Direct Access Not Allowed');
}
oseFirewall::loadJSON ();
class fwstatsv7{
    public function __construct($qatest = false)
    {
        $this->qatest = $qatest;
        $this->db = oseFirewall::getDBO();
        $this->prerequisistes();
    }
    public function prerequisistes()
    {
        oseFirewall::callLibClass('fwscannerv7','fwscannerv7');
        $this->fwscanner = new oseFirewallScannerV7();
        oseFirewall::callLibClass('fwscannerv7','ipManagement');
        $this->ipmanagement = new ipManagement();
    }

    public function getAttackFileContent($ip)
    {
        $attackrecord = null;
        $filepath = OSE_WEBLOGFOLDER.ODS.$ip.ODS.'blocked.php';
        if(file_exists($filepath))
        {
            $content = $this->fwscanner->getAttackFilecontent($ip);
            return $content;
        }else {
            return 0;
        }
    }

    //gets the name of attacks based on the id of the attack
    public function getAttackName($key)
    {
        switch($key)
        {
            case '2': return 'Cross Site Scripting'; break;
            case '3': return 'Cross Site Request Forgery'; break;
            case '4': return 'SQL Injection'; break;
            case '5': return 'Remote File Inclusion'; break;
            case '6': return 'Local File Inclusion'; break;
            case '7': return 'Layer 2 Intrusion'; break;
            case '8': return 'Directory Traversal'; break;
//            case '9': return 'Denial of Service Attack'; break;
            case '10': return 'Local File Modification Attempt'; break;
            case '11': return 'Spamming'; break;
            case '12': return 'Formate String Attack'; break;
            case '13': return 'Inconsistent File Type'; break;
            case '14': return 'Virus File'; break;
            case '15': return 'Brute Force Protection'; break;
            default:
                return 'undefined attack';
                break;
        }
    }

    //return an array with the name of all the attacks from their ids
    public function getAttackNameList($arrayList)
    {
        $result = array();
        foreach($arrayList as $record)
        {
            $name = $this->getAttackName($record);
            array_push($result,$name);
        }
        return $result;
    }

    public function preapreAttackInfoContent($ip)
    {
        $content  = $this->getAttackFileContent($ip);
//        echo '<pre>';
//        print_r($content['variables']);
//        echo '<pre>';
//        exit;
        if($content == 0)
        {
            return $this->fwscanner->prepareSuccessMessage("The ip has been manually blocked by the user");
        }else {
            //set attack names
            $attackname_temp = $this->getAttackNameList($content['attacktype']);
            $attackname = implode('<br/>',$attackname_temp);
            //set file variables
            if(empty($content['variables']))
            {
                $variables = 'N/A';
            }else {
                $variables = $this->formatAssociateArray($content['variables']);
            }

            //info related to the file upolad
            if(empty($content['files']))
            {
                $filevariables = 'N/A';
            }else {
                $filevariables =  $this->formatAssociateArray($content['files']['my-file']);
            }

            if(isset($content['attack']))
            {
                if(is_array($content['attack']))
                {
                    $warningtext = implode('<br/>',$content['attack']);
                }else {
                    $warningtext =$content['attack'];
                }

            }else {
                $warningtext = 'N/A';
            }
            $datetime = $content['date'].'/'.$content['month'].'/'.$content['year'];
            $result = array();
            $result['status'] = 1;
            $result['attackname'] = $attackname;
            $result['variables'] = $variables;
            $result['uploadfile'] = $filevariables;
            $result['warningtext'] = $warningtext;
            $result['ip'] = $content['ip'];
            $result['datetime'] = $datetime;
            $result['score'] = $content['score'];
            $result['attempt'] = $content['attempt'];
            $temp = $this->prepareModal($result);
            return $temp;
        }
    }


    function formatAssociateArray($attributes)
    {
        $dataAttributes = array_map(function($value, $key) {
            return $key.'="'.$value.'"';
        }, array_values($attributes), array_keys($attributes));

        $dataAttributes = implode('<br/>', $dataAttributes);
        return $dataAttributes;
    }

    public function prepareModal($content)
    {
        $temp = "<div width='100%' class='form-horizontal group-border stripped'>
                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('ATTACK_INFORMATION')."</label>
                    </div>
                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('IP_ADDRESS')."</label>
                        <div class='col-sm-9'>".$content['ip']."
                        </div>
                    </div>

                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('Date')."</label>
                        <div class='col-sm-9'>".$content['datetime']."
                        </div>
                    </div>

                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('TYPE_OF_ATTACK')."</label>

                    <div class='col-sm-9'>".$content['attackname']."
                        </div>
                    </div>
                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('STRING_DETECTED')."</label>
                        <div class='col-sm-9'>".$content['warningtext']."
                        </div>
                    </div>
                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('SCANNED_VARIABLES')."</label>
                        <div class='col-sm-9'>".$content['variables']."
                        </div>
                    </div>
                    <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('FILES')."</label>
                        <div class='col-sm-9'>".$content['uploadfile']."
                        </div>
                    </div>
                     <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('SCORE')."</label>
                        <div class='col-sm-9'>".$content['score']."
                        </div>
                    </div>
                     <div class='form-group'>
                        <label class='col-sm-3 control-label'>".oLang::_get('ATTEMPTS')."</label>
                        <div class='col-sm-9'>".$content['attempt']."
                        </div>
                    </div>
                    ";
        $result['info'] = $temp;
        $result['status'] = $content['status'];
        return $result;
    }
}