<?php
/**
 * Created by PhpStorm.
 * User: suraj
 * Date: 6/07/2016
 * Time: 1:42 PM
 */
if (!defined('OSE_FRAMEWORK') && !defined('OSEFWDIR') && !defined('_JEXEC'))
{
    die('Direct Access Not Allowed');
}
oseFirewall::loadJSON ();
class ipManagement{
    private  $iptable = '#__osefirewall_ipmanagement';

    public function __construct($qatest = false)
    {
        $this->qatest = $qatest;
        $this->db = oseFirewall::getDBO();
        $this->prerequisistes();
    }
    public function prerequisistes()
    {
//        $iptable = '#__osefirewall_ipmanagement';
        $iptableexists = $this->db->isTableExists($this->iptable);
        if (!$iptableexists) {
            //if the ip table does not exist
            oseFirewallBase::createBlockIpTable($this->db);
        }
        oseFirewall::callLibClass('fwscannerv7','fwscannerv7');
        $this->fwscanner = new oseFirewallScannerV7();
    }

    //create the new table to store the list  oif blocked ips
//    public function createBlockIpTable()
//    {
//        $query = "CREATE TABLE IF NOT EXISTS `#__osefirewall_ipmanagement` (
//                          `id`      INT(11)      NOT NULL AUTO_INCREMENT,
//                          `ip` VARCHAR(200) NOT NULL UNIQUE,
//                          `status` INT(11) NOT NULL,
//                          `ischecked` TINYINT(1) NOT NULL,
//                          `isspam`  TINYINT(1) NOT NULL,
//                          `lastchecked`  VARCHAR(200) NOT NULL,
//                          `dateadded`  TIMESTAMP,
//                          PRIMARY KEY (`id`)
//                        )
//                          ENGINE = InnoDB  DEFAULT CHARSET = utf8  AUTO_INCREMENT = 1; ";
//        $this->db->setQuery($query);
//        $results = $this->db->loadObject();
//        return $results;
//    }

    //add the blocked ip to the database table
    public function addBlockedIp($ip)
    {
        $ipexistsindb = $this->checkIfIPalreadyexistsInDB($ip);
        if (empty($ipexistsindb)) {
            $varValues = array(
                'ip' => $ip,
                'status' => 2,
                'ischecked' =>0,
                'isspam' =>0,
                'lastchecked' =>0,
                'datetime'=> date('Y-m-d h:i:s'),
            );
            $result = $this->db->addData('insert', '#__osefirewall_ipmanagement', '', '', $varValues);
        } else {
            //ip exists change status to blacklisted
            $varValues = array(
                'status' => 2,
                'datetime'=> date('Y-m-d h:i:s'),
            );
            $result = $this->db->addData('update', '#__osefirewall_ipmanagement', 'ip', $ip, $varValues);
        }
        if($result !== 0)
        {
            return  $this->fwscanner->prepareSuccessMessage("The ip has been added to the black list");
        }
        else {
            return  $this->fwscanner->prepareErrorMessage("There was some problem in adding the ip to the black list");
        }
    }

   /*
    * $array = list of ids
    * $status status that needs to be changed to
    */
    public function changeStatusofIp($array,$status)
    {
        foreach($array as $record)
        {
            //if there is any ip corresponding to the id
            $temp = $this->getIpFromDb($record);
            //if the ip does not exist it will return emptry array
            if(!empty($temp)) {
                //access the ip fiels od the returned  record
                $ip = $temp->ip;
                $date = new DateTime();
                $current_timestamp = $date->getTimestamp();
                if($status == 1) {
                    $varValues = array(
                        'status' => $status,
                        'ischecked' => (int)1,
                        'isspam' => (int)0,
                        'lastchecked' => $current_timestamp,
                        'datetime' => date('Y-m-d h:i:s'),
                    );
                }
                else {
                    $varValues = array(
                        'status' => $status,
                        'datetime' => date('Y-m-d h:i:s')
                    );
                }
                //update the db table
                $result = $this->db->addData('update', '#__osefirewall_ipmanagement', 'ip', $ip, $varValues);
                if($status == 1 && $result!== 0)
                {
                    $this->rmdir_recursive(OSE_WEBLOGFOLDER.ODS.$ip);
                }
                if ($result == 0) {
                    return $this->fwscanner->prepareErrorMessage("There was some problem in adding the ip to the" . $this->getListName($status) . " list");
                }
            }
            else {
                return $this->fwscanner->prepareErrorMessage("There Ip with the provided id does not exist");
            }
        }
        return  $this->fwscanner->prepareSuccessMessage("The records have been updated successfully");
    }

    //return the record with the matfching id
    public function getIpFromDb($id)
    {
        $query = "SELECT `ip` FROM `#__osefirewall_ipmanagement` WHERE `id`=" . $this->db->quoteValue($id);
        $this->db->setQuery($query);
        $result = $this->db->loadObject();
        return $result;
    }


    //get the name of list
    //used to set the return messages
    public function getListName($status)
    {
        if($status == 0)
        {
            return 'Monitor';
        }else if($status == 1)
        {
            return 'White';
        }elseif($status == 2)
        {
            return 'Black';
        }
    }

    //to check if the entry for the ip exists in the database
    public function checkIfIPalreadyexistsInDB($ip)
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE `ip`=" . $this->db->quoteValue($ip);
        $this->db->setQuery($query);
        $result = $this->db->loadResultList();
        return $result;
    }

    //public function return a list of blocked ips   => status == 2
    public function getBlockedIps()
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE `status`= 2";
        $this->db->setQuery($query);
        $result = $this->db->loadResultList();
        return $result;
    }

    //check the db record for the ip if its blocked
    public function isIPBlockedDB($ip)
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE `status`= 2 AND `ip` = '".$ip."'";
        $this->db->setQuery($query);
        $result = $this->db->loadResultList();
        return (!empty($result)) ? true : false;
    }

    //check if an ip is whitelisted
    public function isIPWhiteListedDB($ip)
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE `status`= 1 AND `ip` = '".$ip."'";
        $this->db->setQuery($query);
        $result = $this->db->loadResultList();
        return (!empty($result)) ? true : false;
    }

    //whitelist an already exisitinf ip
    public function monitorIp($ip)
    {
        //status 1 == whitelist
        $varValues = array(
            'status' => 0
        );
        $result = $this->db->addData('update', '#__osefirewall_ipmanagement', 'ip', $ip, $varValues);
        if($result !== 0)
        {
            $this->rmdir_recursive(OSE_WEBLOGFOLDER.ODS.$ip);
            return  $this->fwscanner->prepareSuccessMessage("The ip has been added to the whitelist");
        }
        else {
            return  $this->fwscanner->prepareErrorMessage("There was some problem in adding the ip to the whitelist");
        }
    }

    function rmdir_recursive($dir) {
        foreach(scandir($dir) as $file) {
            if ('.' === $file || '..' === $file) continue;
            if (is_dir("$dir/$file")) $this->rmdir_recursive("$dir/$file");
            else unlink("$dir/$file");
        }
        rmdir($dir);
    }


    //monitor an ip
    public function monitoranIP($ip)
    {
        //status 1 == whitelist
        $varValues = array(
            'status' => 0
        );
        $result = $this->db->addData('update', '#__osefirewall_ipmanagement', 'ip', $ip, $varValues);
        if($result !== 0)
        {
            return  $this->fwscanner->prepareSuccessMessage("The ip has been added to the monitor list");
        }
        else {
            return  $this->fwscanner->prepareErrorMessage("There was some problem in adding the ip to the monitor list");
        }
    }
    //add an ip to the database table
    public function addanIp($ip, $status)
    {
        $isValid = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
        if($isValid) {
            $ipexistsindb = $this->checkIfIPalreadyexistsInDB($ip);
            if (empty($ipexistsindb)) {
                $date = new DateTime();
                $current_timestamp = $date->getTimestamp();
                $varValues = array(
                    'ip' => $ip,
                    'status' => $status,
                    'ischecked' => 0,
                    'isspam' =>0,
                    'lastchecked' =>0,
                    'datetime' => date('Y-m-d h:i:s'),
                );
                $result = $this->db->addData('insert', '#__osefirewall_ipmanagement', '', '', $varValues);
            } else {
                //ip exists change status to blacklisted
                $varValues = array(
                    'status' => $status
                );
                $result = $this->db->addData('update', '#__osefirewall_ipmanagement', 'ip', $ip, $varValues);
            }
            if ($result !== 0) {
                return $this->fwscanner->prepareSuccessMessage("The ip has been added successfully");
            } else {
                return $this->fwscanner->prepareErrorMessage("There was some problem in adding the ip");
            }
        }
        else {
            return $this->fwscanner->prepareErrorMessage("Please enter an valid IP Address");
        }
    }

    //deletes all the entries from the databse
    public function clearIpTABLE()
    {
        $result = $this->db->truncateTable("#__osefirewall_ipmanagement");
        if($result !== 0)
        {
            return  $this->fwscanner->prepareSuccessMessage("The ip table has been cleared ");
        }
        else {
            return  $this->fwscanner->prepareErrorMessage("There was some problem in clearing the IP table");
        }
    }

    //returns all the entries in the database table
    public function getIPInfo()
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE 1";
        $this->db->setQuery($query);
        $temp = $this->db->loadResultList();
        $result = $this->formatIPLog($temp);
        return $result;
    }

    public function getIPinfoDb()
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE 1";
        $this->db->setQuery($query);
        $temp = $this->db->loadResultList();
        return $temp;
    }

    public function formatIPLog($array)
    {
        $temp = array();
        $i= 0;
        foreach($array as $record)
        {
            $temp[$i]['id'] = $record['id'];
            $temp[$i]['ip'] = $record['ip'];
            $temp[$i]['status'] = ($record['status'] == 2) ? $this->getStatusIcon($record['status']).' '.'<i class="text-success glyphicon glyphicon-info-sign" style="cursor:pointer; font-size:20px; float:right; color:#1cab94;" href="javascript:void(0);" onclick="viewAttackInfo(\'' . $record['ip'] . '\')" title = "Find out the reason why this IP has been blocked"></i>': $this->getStatusIcon($record['status']);
            $temp[$i]['datetime'] = $record['dateadded'];
            $i++;
        }
        $result['data'] =$temp;
        $result['recordsFiltered'] = count($temp);
        $result['recordsTotal'] =count($temp);
        return $result;
    }

    public function viewAttackInfo($ip)
    {
        oseFirewall::loadLibClass('fwscannerv7','fwstatsv7');
        $fs = new fwstatsv7();
        $result = $fs->preapreAttackInfoContent($ip);
        return $result;
    }

//    public function prepareAttackInfo($ip)
//    {
//        $filepath = OSE_WEBLOGFOLDER.ODS.$ip.ODS.'blocked.php';
//        if(file_exists($filepath))
//        {
//            $content = $this->fwscanner->getAttackFilecontent($ip);
//            echo '<pre>';
//            print_r($content);
//            echo '<pre>';
//        }else {
//            return $this->fwscanner->prepareSuccessMessage('The blocked file for the ip '.$ip. 'does not exists');
//        }
//    }

    //aceepts list of ips that needs to be deleted
    public function deleteIps($array)
    {
        foreach($array as $record)
        {
            if(!empty($record))
            {
//                $ip = $temp->ip;
                $query = "DELETE FROM `#__osefirewall_ipmanagement` WHERE `id`=".$this->db->quoteValue($record);
                $this->db->setQuery($query);
                $this->db->loadObject();
            }else {
                return $this->fwscanner->prepareErrorMessage("There was some problem in deleting the chose ip(s)");
            }
        }

        return $this->fwscanner->prepareSuccessMessage("The chosen IP's have been deleted");
    }

    //get the $_FILES variable of the uploadedd file
    public function importCSV($files)
    {
        //if the file is not uploaded
        if (empty($files))
        {
            return $this->fwscanner->prepareErrorMessage("Please upload a CSV file, there is no files uploaded");
        }
        else
        {
            $file = $files['csvfile'];
            //check if only the cvs file is uploaded
            if (!in_array($file['type'], array('application/csv', 'text/csv', 'text/comma-separated-values', 'application/vnd.ms-excel')))
            {
                //wrong file format
                return $this->fwscanner->prepareErrorMessage("Please upload CSV files, file types apart from the CSV is not accepted.");
            }
            else
            {
                //csv file
                $result = $this->insertCSVFileinDb($file);
                if ($result['status'] == 1)
                {
                    return $this->fwscanner->prepareSuccessMessage("There CSV files was imported successfully");
                }
                else
                {
                    return $this->fwscanner->prepareErrorMessage("There was some problem in improting the CVS file");
                }
            }
        }
    }

    //get the data row by row and add it to the database
    public function insertCSVFileinDb($file)
    {
        $row = 1;
        $result = true;
        if (($handle = fopen($file['tmp_name'], "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                //get row by row data
                if ($row == 1)
                {
                    //if the heading name of the fields  are not same asa the database one
                    if ($data != $this->headerArray())
                    {
                        return $this->fwscanner->prepareErrorMessage("The CSV file heading format is incorrect. Please follow the instruction to create the CSV file.");
                    }
                }
                else
                {
                    //add row by row to the database table
                    $result = $this->addCSVIPs($data[1], $data[2], $data[3],$data[4],$data[5],$data[6]);
                    if($result['status'] == 0)
                    {
                        return $result;
                    }
                }
                $row++;
            }
            fclose($handle);
        }
        return $result;
    }

    public function addCSVIPs($ip,$status,$ischecked,$isspam,$lastchecked,$dateadded)
    {

        //check if any one of the value is empty
        if((isset($ip)||isset($status)||isset($ischecked)||isset($isspam)||isset($lastchecked)||isset($dateadded))) {
            //check if the ip alredy exists in the databse
            $ipexistsindb = $this->checkIfIPalreadyexistsInDB($ip);
            if (empty($ipexistsindb))
            {
                $varValues = array(
                    'ip' => $ip,
                    'status' => $status,
                    'ischecked' =>$ischecked,
                    'isspam' => $isspam,
                    'lastchecked' =>$lastchecked,
//                    'dateadded' => $dateadded,
                    'dateadded' => date('Y-m-d h:i:s'),
                );
                $result = $this->db->addData('insert', '#__osefirewall_ipmanagement', '', '', $varValues);
                //the result will be 0 if the insert was not successfull
                if ($result !== 0)
                {
                    //insert was successfull
                    return $this->fwscanner->prepareSuccessMessage("The record for the ip " . $ip . "has been successfully imported");
                } else
                {
                    return $this->fwscanner->prepareErrorMessage("There was some problem in importing the record for " . $ip);
                }
            } else
            {
                //the ip already exists in the database
                return $this->fwscanner->prepareSuccessMessage("The record for the ip already exists in the database");
            }
        }
        else
        {
            //one of the values is empty
            return $this->fwscanner->prepareErrorMessage("The values that needs to be entered in the database are empty");
        }
    }

    //contains all the list of heading field of the ipamanagement table
    protected function headerArray () {
        return array("id", "ip", "status", "ischecked", "isspam", "lastchecked", "dateadded");
    }


//    preapre the CSV file locally
//    public function prepareCVSFile($filename)
//    {
//        $filepath = $this->getCompleteCSVFilepath($filename);
//        if(!file_exists(OSE_CSV_EXPORTFILES))
//        {
//            mkdir(OSE_CSV_EXPORTFILES);
//        }
//        $query = "SELECT 'id', 'ip', 'status' ,'ischecked', 'isspam','lastchecked','dateadded'
//                UNION ALL
//                SELECT `id`, `ip`, `status`,`ischecked`,`isspam`,`lastchecked`,`dateadded`
//                    FROM `#__osefirewall_ipmanagement`
//                    INTO OUTFILE '" .$filepath. "' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"'
//                    LINES TERMINATED BY '\\n'";
//        $this->db->setQuery($query);
//        $this->db->loadResultList();
//        if(file_exists($filepath))
//        {
//            return $this->fwscanner->prepareSuccessMessage("The csv file has been generated successfully ");
//        }else {
//            return $this->fwscanner->prepareErrorMessage("There was some problem in generating the cvs file");
//        }
//    }

    // gets the comnplete path for the csv file that needs to be saved
    public function getCompleteCSVFilepath($filename)
    {
     $filepath = OSE_CSV_EXPORTFILES.ODS.$filename.".txt";
     return $filepath;
    }

    //get the contentfrom the local file
//    public function getCSVFileContents($filename)
//    {
//        $temp = $this->prepareCVSFile($filename);
//        if($temp['status'] ==1 )
//        {
//            $filepath = OSE_CSV_EXPORTFILES.ODS.$filename.".txt";
//            if(file_exists($filepath))
//            {
//                $content = file_get_contents($filepath);
//                return $content;
//            }else {
//                return $this->fwscanner->prepareErrorMessage("There was some problem in accessing the cvs file");
//            }
//        }else {
//            return $temp;
//        }
//    }


    //sends the header with the csv file content
    public function downloadcvs_fws7($filename)
    {
//        $filepath = OSE_CSV_EXPORTFILES.ODS.$filename.".txt";
//        $fileContent = $this->getCSVFileContents($filename);
        $fileContent = $this->getDownloadCSVContent();
            if (ob_get_contents()) {
                ob_clean();
            }
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Content-Length: " . strlen($fileContent));
        // Output to browser with appropriate mime type, you choose ;)
        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=$filename");
        print_r($fileContent);
        exit;
    }

    /*
     * Download csv new updated code
     */

    public function getDownloadCSVContent()
    {
        $output = implode(",", $this->headerArray()) . "\n";
        $results = $this->getIPinfoDb();
        foreach ($results as $data) {
            $output .= $this->getTmpOutput($data) . "\n";
        }
        return $output;
    }

    private function getTmpOutput($data)
    {
        $tmp = array();
        $tmp[] = $data['id'];
        $tmp[] = $data['ip'];
        $tmp[] = $data['status'];
        $tmp[] = $data['ischecked'];
        $tmp[] = $data['isspam'];
        $tmp[] = $data['lastchecked'];
        $tmp[] = $data['dateadded'];
        $return = implode(",", $tmp);
        return $return;
    }

    //attach the link to the export button
    public function getExportButton()
    {
        oseFirewall::loadFiles();
        $time = date("Y-m-d");
        $filename = "ip-export-" . $time . ".csv";
        $centnounce = isset($_SESSION['centnounce']) ? $_SESSION['centnounce'] : oseFirewall::loadNounce();
        $url = EXPORT_DOWNLOAD_URL_FWS7 . urlencode($filename) . "&centnounce=" . urlencode($centnounce);
        $exportButton = '<a href="' . $url . '"  id="export-ip-button" target="_blank" class="btn-new tl-center"><i class="glyphicon glyphicon-export"></i> ' . oLang::_get("GENERATE_CSV_NOW") . '</a>';
        return $exportButton;
    }


    public function getStatusIcon($status)
    {
        switch ($status)
        {
            case '1':
                return "<a href='javascript:void(0);' title = 'WhiteList' onClick= '#'><i class='text-success glyphicon glyphicon-ok-sign' title = 'This IP is scurrently whitelisted'></i></a>";
                break;
            case '0':
                return "<a href='javascript:void(0);' title = 'monitor' onClick= '#' ><i class='text-yellow glyphicon glyphicon-eye-open' title = 'This IP is actively monitored'></i></a>";
                break;
            case '2':
                return "<a href='javascript:void(0);' title = 'Blacklist' onClick= '#' ><i class='tisspamcheckext-block glyphicon glyphicon-minus-sign' title = 'This IP is blacklisted'></i></a>";
                break;
            default:
                return '';
                break;
        }
    }

    //check  if the ip has been checked for spam
    public function isspamcheck($ip)
    {
//        $this->ip = '5.248.164.72';
        $query = "SELECT `ischecked`, `isspam`,`lastchecked` FROM ".$this->db->quoteKey($this->iptable)." WHERE `ip` = " . $this->db->quoteValue($ip);
        $this->db->setQuery($query);
        $result = (object)($this->db->loadResult());
        $temp = array();
        if(!empty($result->ischecked))
        {
            $temp['status'] = 1;
            $temp['ischecked'] = $result->ischecked;
            $temp['isspam'] = $result->isspam;
            $temp['timestamp'] = $result->lastchecked;
            return $temp;

        }else {
            //set the values if the record does not exists
            $temp['status'] =0;
            $temp['ischecked'] =0;
            $temp['isspam'] = 0;
            $temp['timestamp'] =0;
            return $temp;
        }
    }

    //update the spam check values in the databse
    public function updateSpamCheck($ip,$type,$value,$current_timestamp)
    {
        $varValues = array(
            'ischecked' => (int)$type,
            'isspam' => (int)$value,
            'lastchecked' => $current_timestamp
        );
        $this->db->addData('update', $this->iptable, 'ip', $ip, $varValues);
    }

    //add an entry into the databsae for the spam check
    public function insertSpamCheck($ip,$type,$value,$current_timestamp)
    {
        $varValues = array(
            'ip' => $ip,
            'status' =>(int)$value,
            'ischecked' => (int)$type,
            'isspam' =>(int)$value,
            'lastchecked' => $current_timestamp,
            'dateadded'=> date('Y-m-d h:i:s'),
        );
        $this->db->addData('insert', $this->iptable, '', '', $varValues);
    }

    //deletes all the blacklisted and monitored records from the db if they are older than 30 days
    public function cronJobsIPTable()
    {
        $query = "SELECT * FROM `#__osefirewall_ipmanagement` WHERE `status`= 1 OR `status` = 2";
        $this->db->setQuery($query);
        $result = $this->db->loadArrayList();
        if(!empty($result))
        {
            foreach($result as $record)
            {
                echo '<br/>';
                echo "record getting scanned is ".$record['ip'];
                echo '<br/>';

                $isexpired = $this->checkRecordExpiry($record['dateadded']);
                if($isexpired)
                {
                    $temp = $this->deleteIps(array($record['id']));
                    if($temp['status'] == 0)
                    {
                        return $temp;
                    }
                }
            }
            return  $this->fwscanner->prepareSuccessMessage("The blocklisted and monitored ips have been deleted");
        }else {
            return $this->fwscanner->prepareErrorMessage("There are no records for the blacklisted and monitored ips");
        }
    }

    //CRON JOB => to chheck the date of the record and returns true if the diffrene is more than 30 days
    //TODO
    public function checkRecordExpiry($record)
    {
        if(isset($record))
        {
            $ts1 = strtotime($record);
            $ts2 =  strtotime(date('Y-m-d h:i:s'));
            $seconds_diff = $ts2 - $ts1;
            $days = $seconds_diff/86400;
            if((int)$days >30)
            {
                //the record has expired
                return true;
            }else {
                //the records has not expired
                return false;
            }
        }else {
            return true;
        }
    }
}